package graph;

public interface Edge<E> {
    public E getElement();
}
