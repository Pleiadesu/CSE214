package graph;

public interface Vertex<V> {
    public V getElement();
}
